<script>
export default {
  name: 'app'
};
</script>

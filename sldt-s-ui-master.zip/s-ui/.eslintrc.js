module.exports = {
  root: true,
  env: {
    node: true
  },
  extends: [
    'plugin:vue/essential',
    '@vue/standard'
  ],
  rules: {
    // 不强制驼峰法命名
    camelcase: 0,
    // 单引号
    quotes: [
      'error',
      'single'
    ],
    // 语句强制分号结尾
    semi: [
      'error',
      'always'
    ],
    // 可以不使用全等
    eqeqeq: 0,
    // 允许使用console
    'no-console': 0,
    // 允许直接return;
    'no-useless-return': 0,
    // 禁止使用debugger
    'no-debugger': 0,
    'prefer-promise-reject-errors': 0,
    'standard/no-callback-literal': 0,
    'no-tabs': 0,
    'no-unused-expressions': 0,
    'no-mixed-operators': 0
  },
  parserOptions: {
    parser: 'babel-eslint'
  },
  globals: {
    uni: true,
    getCurrentPages: true
  }
};

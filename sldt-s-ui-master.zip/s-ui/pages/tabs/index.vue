<template>
  <section class="Tabs-Page">
    <div class="article">
      <p class="title">普通</p>
      <s-tabs effect @change="change" @render="render">
        <s-tab v-for="i of 5" :title="'Tab'+(i+1)" :key="i">内容{{i+1}}</s-tab>
      </s-tabs>
    </div>

    <div class="article">
      <p class="title">超出可滚动</p>
      <s-tabs effect @change="change" @render="render">
        <s-tab v-for="i of 15" :title="'Tab'+(i+1)" :key="i">内容{{i+1}}</s-tab>
      </s-tabs>
    </div>

    <div class="article">
      <p class="title">自定义导航间距样式</p>
      <s-tabs class="custom-tabs">
        <s-tab title="Tab1">1</s-tab>
        <s-tab title="Tab2">2</s-tab>
      </s-tabs>
    </div>

    <div class="article">
      <p class="title">slot-title为true时</p>
      <p class="desc">s-tab下的内容将成为导航的内容填充，面板区域需要自己写，可配合swiper实现滑动效果</p>
      <s-tabs slot-title v-model="activeTab">
        <s-tab v-for="item of tabList" :key="item">Tab{{item}}</s-tab>
      </s-tabs>
    </div>
  </section>
</template>

<script>
import sTabs from '@/s-ui/s-tabs';
import sTab from '@/s-ui/s-tab';

export default {
  components: {
    sTabs,
    sTab
  },
  data () {
    return {
      tabList: [1, 2, 3, 4, 5, 6, 7],
      activeTab: 3
    };
  },
  methods: {
    change (index) {
      console.log('change:', index);
    },
    render (index) {
      console.log('render:', index);
    }
  },
  onLoad () {
  }
};
</script>

<style lang="scss">
.Tabs-Page {
  .article {
    .title {
      padding: 20rpx;
      font-size: 30rpx;
      text-align: center;
    }
    .desc {
      padding: 0 30rpx;
      font-size: 26rpx;
    }
  }
  ::v-deep .s-tabs {
    .s-tab-nav {
      padding: 0 20rpx;
    }
    .s-tab-panel {
      padding: 30rpx 40rpx;
    }
  }
  .custom-tabs {
    ::v-deep .s-tab-nav-view {
      display: flex;
      justify-content: center;
      .s-tab-nav {
        flex: 0 0 auto;
      }
    }
  }
}
</style>

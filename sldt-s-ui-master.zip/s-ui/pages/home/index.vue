<template>
  <section class="Home-Page">
    <ul class="tab-list">
      <li
        v-for="(item,index) of list"
        :key="index"
        @click="jumpTo(item)"
      >{{item.style.navigationBarTitleText}}</li>
    </ul>
  </section>
</template>

<script>
export default {
  data () {
    return {
      list: [
        {
          path: 'pages/picker/index',
          style: {
            navigationBarTitleText: 'picker'
          }
        },
        {
          path: 'pages/tabs/index',
          style: {
            navigationBarTitleText: '选项卡，tabs'
          }
        },
        {
          path: 'pages/popup/index',
          style: {
            navigationBarTitleText: '弹框'
          }
        },
        {
          path: 'pages/pull-scroll/index',
          style: {
            navigationBarTitleText: '下拉刷新，上拉加载'
          }
        },
        {
          path: 'pages/table/index',
          style: {
            navigationBarTitleText: '表格'
          }
        }
      ]
    };
  },
  methods: {
    jumpTo (item) {
      uni.navigateTo({ url: '/' + item.path });
    }
  }
};
</script>

<style lang="scss">
.Home-Page {
  .tab-list {
    li {
      font-size: 28rpx;
      padding: 30rpx;
      text-align: center;

      &:not(:first-child) {
        border-top: 2rpx solid #eaeaea;
      }
    }
  }
}
</style>

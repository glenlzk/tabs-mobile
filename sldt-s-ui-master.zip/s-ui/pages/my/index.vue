<template>
  <section class="My-Page"></section>
</template>

<script>
export default {

};
</script>

<style lang="scss">
.My-Page {
}
</style>

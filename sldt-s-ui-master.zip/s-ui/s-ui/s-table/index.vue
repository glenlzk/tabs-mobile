<template>
  <div class="s-table" :class="[
    {'s-table-border':border},
    {'s-table-center':center}
  ]">
    <div class="s-table-header">
      <div
        class="s-table-th"
        v-for="(column,columnIndex) of columns"
        :key="columnIndex"
        :style="{flex:getTdWidth(column)}"
        @click="thClick(column,columnIndex)"
      >
        {{column.title}}
        <div class="s-table-sort-wrap" v-if="hasSort(column)">
          <div class="sort-icon" :style="{color:column.sortBy == sortBy && sortOrder == 'asc'? sortActiveColor:sortColor}"></div>
          <div class="sort-icon" :style="{color:column.sortBy == sortBy && sortOrder == 'desc'? sortActiveColor:sortColor}"></div>
        </div>
      </div>
    </div>
    <div class="s-table-body">
      <div class="s-table-tr" :class="[getRowClassName(row,rowIndex)]" v-for="(row,rowIndex) of list" :key="rowIndex">
        <div class="s-table-td" v-for="(column,columnIndex) of columns" :key="columnIndex" :style="{flex:getTdWidth(column)}">
          <slot :row="row" :rowIndex="rowIndex" :column="column" :columnIndex="columnIndex" :parent="parent">{{row[column.key]}}</slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 's-table',
  props: {
    columns: {
      default: () => []
    },
    list: {
      type: Array,
      default: () => []
    },
    center: {
      type: Boolean,
      default: true
    },
    border: {
      type: Boolean,
      default: false
    },
    rowClassName: {
      type: [Function, String],
      default: ''
    },
    sortColor: {
      type: String,
      default: '#999999'
    },
    sortBy: {
      default: ''
    },
    sortOrder: {
      type: String,
      default: ''
    },
    sortActiveColor: {
      type: String,
      default: '#22ade1'
    }
  },
  computed: {
    parent () {
      return this.$parent.$data;
    }
  },
  methods: {
    hasSort (column) {
      return typeof column.sortBy !== 'undefined';
    },
    getTdWidth (column) {
      const w = column.width;
      if (w) {
        if (String(w).indexOf('%') > -1) {
          return '0 0 ' + w;
        } else {
          return '0 0 ' + parseInt(w) + 'rpx';
        }
      }
      return '1 0 0';
    },
    getRowClassName (row, rowIndex) {
      if (typeof this.rowClassName === 'function') {
        return this.rowClassName.call(this.$parent, row, rowIndex);
      }
      return this.rowClassName;
    },
    thClick (column, columnIndex) {
      if (this.hasSort(column)) {
        if (this.sortBy != column.sortBy) {
          this.$emit('update:sortBy', column.sortBy);
          this.$emit('update:sortOrder', 'asc');
        } else {
          if (this.sortOrder == 'asc') {
            this.$emit('update:sortOrder', 'desc');
          } else {
            this.$emit('update:sortOrder', 'asc');
          }
        }
        this.$emit('sort', column, columnIndex);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.s-table {
  .s-table-header,
  .s-table-tr {
    display: flex;
  }
  .s-table-th,
  .s-table-td {
    display: flex;
    align-items: center;
    padding: 10rpx;
    min-height: 60rpx;
    box-sizing: border-box;
  }
  &.s-table-center {
    .s-table-th,
    .s-table-td {
      text-align: center;
      justify-content: center;
    }
  }
  &.s-table-border {
    .s-table-th,
    .s-table-td {
      border: 1rpx solid #e4e7ed;
      &:not(:last-child) {
        border-right: 0;
      }
    }
    .s-table-tr .s-table-td {
      border-top: 0;
    }
  }
  .s-table-sort-wrap {
    margin-left: 0.25em;
    .sort-icon {
      width: 0;
      height: 0;
      border-right: 0.24em solid transparent;
      border-left: 0.24em solid transparent;
      &:first-child {
        border-bottom: 0.33em solid currentColor;
      }

      &:last-child {
        border-top: 0.33em solid currentColor;
        margin-top: 0.14em;
      }
    }
  }
}
</style>

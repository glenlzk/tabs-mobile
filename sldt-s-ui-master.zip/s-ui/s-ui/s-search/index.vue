<template>
  <div class="s-search" :class="{'is-fixed':fixed}" :style="{height:height+'rpx'}">
    <div class="s-search-panel" :style="{height:height+'rpx',background}">
      <slot name="left"></slot>
      <div class="s-search-conent">
        <text class="s-search-icon"></text>
        <input
          class="s-search-input"
          type="text"
          :placeholder="placeholder"
          confirm-type="search"
          :adjust-position="false"
          :value="value"
          @input="onInput"
          @confirm="onConfirm"
        />
      </div>
      <div class="s-search-action" v-if="showAction">
        <slot name="action">
          <div @click="onAction" :style="{color:actionColor}">{{actionText}}</div>
        </slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 's-search',
  props: {
    fixed: {
      type: Boolean,
      default: false
    },
    height: {
      type: [Number, String],
      default: 80
    },
    placeholder: {
      type: String,
      default: '请输入搜索关键字'
    },
    value: {
      default: ''
    },
    background: {
      type: String,
      default: '#f4f4f4'
    },
    showAction: {
      type: Boolean,
      default: false
    },
    actionText: {
      type: String,
      default: '搜索'
    },
    actionColor: {
      type: String,
      default: '#26ABCC'
    }
  },
  methods: {
    onInput (e) {
      this.$emit('input', String(e.detail.value).trim());
    },
    onConfirm () {
      this.$emit('confirm', this.value);
    },
    onAction () {
      this.$emit('action', this.value);
    }
  }
};
</script>

<style lang="scss" scoped>
.s-search {
  &-panel {
    display: flex;
    padding: 10rpx 30rpx;
    box-sizing: border-box;
  }
  &.is-fixed &-panel {
    position: fixed;
    left: 0;
    right: 0;
    z-index: 9;
  }
  &-conent {
    flex: 1;
    height: 100%;
    border-radius: 5rpx;
    background-color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #333333;
  }
  &-action {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-left: 20rpx;
  }
  &-icon {
    font-size: 34rpx;
    color: #666666;
    margin-left: 25rpx;
  }
  &-input {
    flex: 1;
    height: 100%;
    display: flex;
    align-items: center;
    font-size: 26rpx;
    padding: 0 20rpx;
  }
}
</style>

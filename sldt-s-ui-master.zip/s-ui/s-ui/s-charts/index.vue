<template>
  <div :style="{ width: width + 'rpx', height: height + 'rpx' }" v-if="canvasId">
    <canvas
      v-if="showCanvas"
      :id="canvasId"
      :canvasId="canvasId"
      :style="{ width: width + 'rpx', height: height + 'rpx' }"
      @click="click"
      @touchstart="touchstart"
      @touchmove="touchmove"
      @touchend="touchend"
    ></canvas>
    <image :style="{ width: width + 'rpx', height: height + 'rpx' }" v-else-if="renderImg && imgSrc" :src="imgSrc" />
  </div>
</template>

<script>
import Ucharts from './u-charts.js';
const defaultOpts = {
  fontSize: 12,
  formatToolTip (item, category) {
    return category + ' ' + item.name + ':' + item.data;
  }
};
export default {
  name: 's-charts',
  props: {
    width: {
      type: [Number, String],
      default: 750
    },
    height: {
      type: [Number, String],
      default: 500
    },
    renderImg: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      canvasId: '',
      showCanvas: true,
      imgSrc: ''
    };
  },
  watch: {
    renderImg () {
      if (this.renderImg) {
        uni.canvasToTempFilePath({
          x: 0,
          y: 0,
          width: this.cWidth,
          height: this.cHeight,
          canvasId: this.canvasId,
          complete: (res) => {
            this.showCanvas = false;
            this.imgSrc = res.tempFilePath;
          }
        }, this);
      } else {
        this.showCanvas = true;
        if (this.opts) {
          this.init({ animation: false });
        }
      }
    }
  },
  computed: {
    cWidth () {
      return uni.upx2px(parseInt(this.width));
    },
    cHeight () {
      return uni.upx2px(parseInt(this.height));
    }
  },
  created () {
    this.canvasId = 's-charts-' + Math.random().toString(36).substr(2);
  },
  methods: {
    init (opts = {}) {
      this.opts = Object.assign({}, defaultOpts, this.opts, opts);
      this.$nextTick(() => {
        this.$uChart = new Ucharts({
          $this: this,
          canvasId: this.canvasId,
          width: this.cWidth,
          height: this.cHeight,
          ...this.opts
        });
      });
    },
    click (e) {
      if (this.$uChart) {
        this.$uChart.showToolTip(e, {
          format: this.opts.formatToolTip
        });
      }
    },
    touchstart (e) {
      this.$uChart && this.$uChart.scrollStart(e);
    },
    touchmove (e) {
      this.$uChart && this.$uChart.scroll(e);
    },
    touchend (e) {
      this.$uChart && this.$uChart.scrollEnd(e);
    }
  }
};
</script>
